---
name: elegantify
description: Find the most elegant solution to a design or implementation problem by combining structured reasoning, cross-domain research, and rigorous design guardrails. Use when the user says "elegantify", "make this elegant", "find elegance", "break tunnel vision", or asks for the best/cleanest/most beautiful solution to a problem.
---

# Elegantify

Elegance is what remains when you've removed everything that doesn't earn its place.

## Process

Use `mcp__sequential-thinking__sequentialthinking` throughout.

### 1. Decompose

What is the ACTUAL problem (not the symptom)? What constraints exist? What's already in the codebase? What would the naive solution look like — the one to beat?

### 2. Search Outside

Break tunnel vision. Search for how OTHER domains solve analogous problems. Use web search and GitHub search tools. The goal: find at least one cross-domain insight that reframes the problem.

Think: biology, physics, mathematics, architecture, music, cooking, espionage, network theory, information theory — whatever domain maps to the problem's STRUCTURE, not its surface.

### 3. The Elegance Test

Every candidate must pass ALL five:

| Test | Question | Fail Signal |
|------|----------|-------------|
| **Simplicity** | Explain it in one sentence? | Needs a paragraph → not elegant |
| **Inevitability** | Feels like the ONLY right answer? | Alternatives feel equally valid → dig deeper |
| **Removal** | Remove any part without breaking it? | Yes → not minimal yet |
| **Extension** | Add a variant without changing existing code? | No → wrong abstraction |
| **Negative Space** | Name 3 things you chose NOT to build? | Can't → haven't explored enough |

### 4. Verify

Before claiming the design is ready, ask: **what skills might catch something I missed?**

- Load `advanced-design` — run Phase 5 Review Gate (G-SCOPE-1, G-PATTERN-1, G-CONTRACT-1, G-SIMPLE-1). If any fails, return to step 3.
- If implementing code: load `llm-guardrails` (screens for LLM failure modes) and `advanced-debugging` (root cause analysis).
- If the domain is specialized: search for a domain-specific skill. Even 1% chance a skill exists = check. Use the Skill tool to browse available skills or ask "what skills relate to [domain]?"
- If the solution touches security, testing, or infrastructure: there's almost certainly a skill for it. Load it. The 30 seconds spent loading beats the hours spent fixing what it would have caught.

### 5. Present

1. One-sentence insight
2. Architecture (types or diagram)
3. What it replaces and why
4. What you chose NOT to build and why

## Reference

See `references/elegance-patterns.md` for patterns discovered across sessions. Add new ones as you find them.
